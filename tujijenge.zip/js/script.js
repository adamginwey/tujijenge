function calculateLoan() {
  const amount = parseFloat(document.getElementById('loanAmount').value);
  const interestRate = parseFloat(document.getElementById('interestRate').value);
  const term = parseFloat(document.getElementById('loanTerm').value);

  const monthlyInterest = (interestRate / 100) / 12;
  const numberOfPayments = term * 12;
  const monthlyPayment = (amount * monthlyInterest) / (1 - Math.pow(1 + monthlyInterest, -numberOfPayments));

  if (!isNaN(monthlyPayment)) {
    document.getElementById('monthlyPayment').innerText = `Monthly Payment: TZS ${monthlyPayment.toFixed(2)}`;
  } else {
    document.getElementById('monthlyPayment').innerText = 'Please enter valid numbers.';
  }
}
